"""Constraint-driven crossword agent."""
